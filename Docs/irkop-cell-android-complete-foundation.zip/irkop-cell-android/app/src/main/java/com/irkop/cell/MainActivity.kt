package com.irkop.cell

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.irkop.cell.core.ApiClient
import com.irkop.cell.core.SessionManager
import com.irkop.cell.data.Repository
import com.irkop.cell.data.array
import com.irkop.cell.data.displayValue
import com.irkop.cell.data.string
import com.irkop.cell.ui.AppViewModel
import com.irkop.cell.ui.ScreenViewModel
import kotlinx.serialization.json.*
import java.text.NumberFormat
import java.util.Locale

private val Rupiah = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val session = SessionManager(applicationContext)
        val repo = Repository(ApiClient(session).api)
        setContent {
            val appVm: AppViewModel = viewModel(factory = SimpleFactory { AppViewModel(session, repo) })
            MaterialTheme {
                IRKOPCell(appVm, repo)
            }
        }
    }
}

@Composable
private fun IRKOPCell(appVm: AppViewModel, repo: Repository) {
    val state by appVm.state.collectAsState()
    when {
        state.loading -> LoadingScreen()
        state.user == null -> LoginScreen(state.error, appVm::login, appVm::clearError)
        else -> MainScaffold(state.user!!, appVm::logout, repo)
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
private fun LoginScreen(error: String?, login: (String, String) -> Unit, clear: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("IRKOP CELL", style = MaterialTheme.typography.headlineLarge)
        Text("Konter Management", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(username, { username = it }, label = { Text("Username") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            password, { password = it }, label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))
        Button(
            enabled = username.isNotBlank() && password.isNotBlank(),
            onClick = { login(username.trim(), password) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("LOGIN") }
        if (error != null) {
            Spacer(Modifier.height(12.dp))
            Text(error, color = MaterialTheme.colorScheme.error)
            LaunchedEffect(error) { clear() }
        }
    }
}

@Composable
private fun MainScaffold(user: com.irkop.cell.core.UserSession, logout: () -> Unit, repo: Repository) {
    val nav = rememberNavController()
    val destinations = listOf(
        Triple("dashboard", "Dashboard", Icons.Default.Home),
        Triple("kasir", "Kasir", Icons.Default.PointOfSale),
        Triple("transaksi", "Transaksi", Icons.Default.ReceiptLong),
        Triple("lainnya", "Lainnya", Icons.Default.MoreHoriz)
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("IRKOP CELL") },
                actions = { IconButton(onClick = logout) { Icon(Icons.Default.Logout, "Logout") } }
            )
        },
        bottomBar = {
            NavigationBar {
                destinations.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute(nav) == route,
                        onClick = { nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(nav, startDestination = "dashboard", Modifier.padding(padding)) {
            composable("dashboard") { DashboardScreen(repo) }
            composable("kasir") { KasirScreen(repo) }
            composable("transaksi") { TransaksiScreen(repo) }
            composable("lainnya") { MoreScreen(user, nav) }
            composable("produk") { GenericListScreen("Produk", repo, { repo.produk() }) }
            composable("pelanggan") { GenericListScreen("Pelanggan", repo, { repo.pelanggan() }) }
            composable("kasbon") { GenericListScreen("Kasbon", repo, { repo.kasbon() }) }
            composable("pengeluaran") { GenericListScreen("Pengeluaran", repo, { repo.pengeluaran() }) }
            composable("service") { GenericListScreen("Service HP", repo, { repo.serviceHp() }) }
            composable("akun") { GenericListScreen("Akun Uang", repo, { repo.akun() }) }
            composable("laporan") { ReportScreen(repo) }
            composable("admin") { AdminScreen(user) }
        }
    }
}

@Composable
private fun currentRoute(nav: NavHostController): String? =
    nav.currentBackStackEntryAsState().value?.destination?.route

@Composable
private fun DashboardScreen(repo: Repository) {
    val vm: ScreenViewModel = viewModel(factory = SimpleFactory { ScreenViewModel(repo) })
    LaunchedEffect(Unit) { vm.load { repo.kasirCurrent() } }
    val data by vm.data.collectAsState()
    val loading by vm.loading.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Dashboard", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        if (loading) CircularProgressIndicator()
        data?.let {
            InfoCard("Status Kasir", it.string("status") ?: "-")
            InfoCard("Tanggal", it.string("tanggal") ?: "-")
            Text("Ringkasan dari API /kasir/current", style = MaterialTheme.typography.bodySmall)
        }
        vm.error.collectAsState().value?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun KasirScreen(repo: Repository) {
    val vm: ScreenViewModel = viewModel(factory = SimpleFactory { ScreenViewModel(repo) })
    var openingMode by remember { mutableStateOf(false) }
    var closingMode by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.load { repo.kasirCurrent() } }
    val data by vm.data.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Kasir", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        data?.let {
            InfoCard("Status", it.string("status") ?: "-")
            val closing = it.array("closing")
            closing?.take(3)?.forEach { item ->
                Text(item.displayValue(), style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { openingMode = true }, modifier = Modifier.fillMaxWidth()) { Text("OPENING") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { closingMode = true }, modifier = Modifier.fillMaxWidth()) { Text("CLOSING") }
    }
    if (openingMode) {
        SimpleAmountDialog("Saldo Awal Tunai Laci", amount, { amount = it }, {
            vm.create(
                buildJsonObject { putJsonArray("saldo_awal") { add(buildJsonObject {
                    put("nama_akun", "Tunai Laci"); put("saldo", amount.toLongOrNull() ?: 0)
                }) } }
            ) { repo.kasirOpening(listOf("Tunai Laci" to (amount.toLongOrNull() ?: 0))) }
            openingMode = false
        }) { openingMode = false }
    }
    if (closingMode) {
        SimpleAmountDialog("Saldo Real Tunai Laci", amount, { amount = it }, {
            vm.create(
                buildJsonObject { putJsonArray("saldo_real") { add(buildJsonObject {
                    put("nama_akun", "Tunai Laci"); put("saldo_real", amount.toLongOrNull() ?: 0)
                }) } }
            ) { repo.kasirClosing(listOf("Tunai Laci" to (amount.toLongOrNull() ?: 0)), note) }
            closingMode = false
        }) { closingMode = false }
    }
}

@Composable
private fun TransaksiScreen(repo: Repository) {
    val vm: ScreenViewModel = viewModel(factory = SimpleFactory { ScreenViewModel(repo) })
    var q by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { vm.load { repo.transaksi() } }
    val data by vm.data.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Transaksi", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(q, { q = it }, label = { Text("Cari transaksi / produk / pelanggan") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        Button(onClick = { vm.load { repo.transaksi(q.takeIf { it.isNotBlank() }) } }) { Text("CARI") }
        Spacer(Modifier.height(12.dp))
        JsonList(data, "items")
        vm.error.collectAsState().value?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun MoreScreen(user: com.irkop.cell.core.UserSession, nav: NavHostController) {
    val pages = listOf(
        "produk" to "Produk",
        "pelanggan" to "Pelanggan",
        "kasbon" to "Kasbon",
        "pengeluaran" to "Pengeluaran",
        "service" to "Service HP",
        "akun" to "Akun Uang",
        "laporan" to "Laporan",
        "admin" to "Admin"
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item { Text("Menu", style = MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(12.dp)) }
        items(pages.filter { it.first != "admin" || user.role.equals("admin", true) }) { (route, label) ->
            ElevatedButton(onClick = { nav.navigate(route) }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(label)
            }
        }
    }
}

@Composable
private fun GenericListScreen(title: String, repo: Repository, loader: suspend () -> JsonObject) {
    val vm: ScreenViewModel = viewModel(factory = SimpleFactory { ScreenViewModel(repo) })
    LaunchedEffect(Unit) { vm.load(loader) }
    val data by vm.data.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        JsonList(data, "items")
        vm.error.collectAsState().value?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
private fun ReportScreen(repo: Repository) {
    val vm: ScreenViewModel = viewModel(factory = SimpleFactory { ScreenViewModel(repo) })
    var month by remember { mutableStateOf(java.time.LocalDate.now().toString().substring(0, 7)) }
    LaunchedEffect(Unit) { vm.load { repo.laporanBulan(month) } }
    val data by vm.data.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Laporan Bulanan", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(month, { month = it }, label = { Text("YYYY-MM") })
        Spacer(Modifier.height(8.dp))
        Button(onClick = { vm.load { repo.laporanBulan(month) } }) { Text("MUAT LAPORAN") }
        Spacer(Modifier.height(12.dp))
        data?.let {
            listOf("jumlah_transaksi", "omzet", "laba", "net").forEach { key ->
                InfoCard(key, it[key]?.displayValue() ?: "-")
            }
        }
    }
}

@Composable
private fun AdminScreen(user: com.irkop.cell.core.UserSession) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Admin", style = MaterialTheme.typography.headlineMedium)
        Text("Role: ${user.role}")
        Spacer(Modifier.height(12.dp))
        Text("Modul admin terhubung ke endpoint users, permissions, gaji, settings, logs, dan akun pada API v1.")
    }
}

@Composable
private fun JsonList(data: JsonObject?, key: String) {
    val array = data?.array(key) ?: return
    LazyColumn {
        items(array) { item ->
            ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text(item.displayValue(), Modifier.padding(12.dp))
            }
        }
    }
}

@Composable
private fun InfoCard(label: String, value: String) {
    ElevatedCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun SimpleAmountDialog(
    title: String,
    amount: String,
    onAmount: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                amount, onAmount,
                label = { Text("Nominal rupiah") }
            )
        },
        confirmButton = { Button(onClick = onConfirm) { Text("SIMPAN") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("BATAL") } }
    )
}

private class SimpleFactory<T : androidx.lifecycle.ViewModel>(
    private val creator: () -> T
) : androidx.lifecycle.ViewModelProvider.Factory {
    override fun <VM : androidx.lifecycle.ViewModel> create(modelClass: Class<VM>): VM =
        creator() as VM
}
