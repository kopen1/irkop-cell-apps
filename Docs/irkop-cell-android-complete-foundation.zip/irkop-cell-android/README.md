# IRKOP CELL — Android Native

Android native client for IRKOP CELL API Contract v1.0.

## API

Default:

`https://konter.irkop.workers.dev/api/v1/`

The API URL can be overridden:

`gradle assembleDebug -PAPI_BASE_URL=https://example/api/v1/`

Or set the GitHub Actions repository variable:

`API_BASE_URL`

## Implemented foundation

- Kotlin 2.0
- Jetpack Compose + Material 3
- Retrofit + OkHttp
- Kotlin Serialization
- DataStore JWT session
- Bearer authorization interceptor
- Login + `/auth/me` + logout
- Dashboard
- Kasir current/opening/closing
- Transaksi list/search
- Produk
- Pelanggan
- Kasbon
- Pengeluaran
- Service HP
- Akun
- Laporan bulanan
- Admin entry point
- GitHub Actions debug build
- GitHub Actions tag release

## GitHub Actions

Push/PR -> debug APK artifact.

Tag `v1.0.0` -> release APK + GitHub Release.

The release workflow currently produces an unsigned release APK. Add Android signing secrets and a keystore step before distributing a production-signed APK.

## Important

The app deliberately does not embed:
- JWT tokens
- bootstrap secret
- NotifHook API key
- Android signing key

Provider-specific NotifHook parsing remains a backend concern per API Contract v1.0.
