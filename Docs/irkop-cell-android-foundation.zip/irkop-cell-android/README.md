# IRKOP CELL Android

Native Android foundation for IRKOP CELL.

## Stack
- Kotlin
- Jetpack Compose
- Retrofit
- Kotlin Serialization
- DataStore
- GitHub Actions

## API
Default:
https://konter.irkop.workers.dev/api/v1/

Override at build time:
./gradlew assembleDebug -PAPI_BASE_URL=https://example/api/v1/

## Build
Open in Android Studio or run:
./gradlew assembleDebug

The GitHub Actions workflow builds and uploads the debug APK as an artifact.
